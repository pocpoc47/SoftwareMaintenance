package devices;

public interface DeviceInterface {
	void turnOn();
	void turnOff();
	void toggle();
}
