package home;

import devices.Lock;

public abstract class Room  {


	
	public Room(){
		
	}

	public Lock getLock() {
		return null;
	}
}