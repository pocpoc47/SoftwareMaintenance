package home;

import java.util.ArrayList;

import devices.*;
import sensors.*;

public class Garage extends Room {

}
