package actuators;
import java.util.ArrayList;

import home.Room;
import sensors.*;

public abstract class Actuator {
	
}
