package sensors;

public interface Sensor {
	public void update();
}
